export type Unit = "lb" | "kg";

export type BlockType = "lift" | "str" | "gym" | "acc" | "metcon" | "cardio" | "other";

export type SetLine = { w: string; r: string; p?: string; d?: number };

export type Exercise = { name: string; u?: "reps" | "sec" | "min"; sets: SetLine[] };

export type Metcon = { fmt: string; cap: string; desc: string; score: string; rx: string };

export type Cardio = { mod: string; dist: string; time: string; notes: string };

export type Block = {
  type: BlockType;
  ex?: Exercise[];
  m?: Metcon;
  c?: Cardio;
  txt?: string;
};

export type Session = {
  id: string;
  date: string;
  title: string;
  notes: string;
  blocks: Block[];
  rev: string;
};

export type Plan = {
  id: string;
  title: string;
  notes: string;
  group: string;
  blocks: Block[];
  rev: string;
};

export type Draft = {
  id: string;
  date: string;
  title: string;
  notes: string;
  blocks: Block[];
  plan?: boolean;
  group?: string;
};

export type Orm = { n: string; v: number };

export type Food = { n: string; k: number; g: number };

export type FoodItem = { n: string; cal: number; g: number };

export type BoxInfo = {
  id: string;
  name: string;
  role: "coach" | "athlete";
  coachName: string;
};

export type Snapshot = {
  name: string;
  unit: Unit;
  sessions: Session[];
  plans: Plan[];
  orms: Orm[];
  foods: Food[];
  food: Record<string, FoodItem[]>;
  draft: Draft | null;
  box: BoxInfo | null;
};

export type RosterAthlete = { id: string; name: string; sessions: Session[] };

export type Roster = { boxName: string; code: string; athletes: RosterAthlete[] };

export const BLOCKS: Record<BlockType, { n: string; k: "sets" | "metcon" | "cardio" | "note" }> = {
  lift: { n: "Weightlifting", k: "sets" },
  str: { n: "Strength", k: "sets" },
  gym: { n: "Gymnastics & Skills", k: "sets" },
  metcon: { n: "MetCon", k: "metcon" },
  cardio: { n: "Cardio", k: "cardio" },
  acc: { n: "Accessory", k: "sets" },
  other: { n: "Other / Notes", k: "note" },
};

export const PRESETS: [string, BlockType[]][] = [
  ["Weightlifting", ["lift"]],
  ["Lift + MetCon", ["lift", "metcon"]],
  ["Lift + Gymnastics & Skills", ["lift", "gym"]],
  ["Gymnastics & Skills + MetCon", ["gym", "metcon"]],
  ["Lift + Cardio", ["lift", "cardio"]],
  ["Strength + MetCon", ["str", "metcon"]],
  ["MetCon only", ["metcon"]],
];

export const DEX = [
  "Back Squat", "Front Squat", "Overhead Squat", "Deadlift", "Clean", "Power Clean",
  "Squat Clean", "Hang Power Clean", "Clean & Jerk", "Snatch", "Power Snatch", "Hang Snatch",
  "Push Press", "Strict Press", "Push Jerk", "Split Jerk", "Bench Press", "Thruster",
  "Pull-up", "Chest-to-Bar Pull-up", "Muscle-up", "Handstand Push-up", "Handstand Walk",
  "Toes-to-Bar", "Ring Dip", "Box Jump", "Wall Ball", "Kettlebell Swing", "Double Under",
  "Rope Climb", "Pistol Squat", "Handstand Hold", "L-Sit", "Front Lever", "Planche Hold",
  "Wall Sit", "Hollow Hold", "Dead Hang", "Pause Back Squat", "Tempo Back Squat", "Barbell Row",
];

export const SET_TYPES = new Set<BlockType>(["lift", "str", "gym", "acc"]);

const METCON_FMTS = ["AMRAP", "For Time", "EMOM", "Tabata", "Intervals", "Chipper", "Other"];
const CARDIO_MODS = ["Row", "Run", "Bike", "Ski", "Swim", "Jump rope", "Other"];

export function pad(n: number) {
  return String(n).padStart(2, "0");
}

export function ymd(d: Date) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function today() {
  return ymd(new Date());
}

export function addD(x: string, n: number) {
  const d = new Date(`${x}T00:00`);
  d.setDate(d.getDate() + n);
  return ymd(d);
}

export function monOf(x: string) {
  return addD(x, -((new Date(`${x}T00:00`).getDay() + 6) % 7));
}

export function fmtDate(d: string) {
  const dt = new Date(`${d}T00:00`);
  if (Number.isNaN(dt.getTime())) return d;
  return dt.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
}

export const WD = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
export const MN = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

export function revNow() {
  return new Date().toISOString();
}

export function uid() {
  return crypto.randomUUID();
}

export function mk(t: BlockType): Block {
  if (t === "metcon") return { type: t, m: { fmt: "AMRAP", cap: "", desc: "", score: "", rx: "RX" } };
  if (t === "cardio") return { type: t, c: { mod: "Row", dist: "", time: "", notes: "" } };
  if (t === "other") return { type: t, txt: "" };
  return { type: t, ex: [{ name: "", sets: [{ w: "", r: "" }] }] };
}

function clip(v: unknown, max: number) {
  return typeof v === "string" ? v.slice(0, max) : "";
}

function oneOf(v: string, list: string[], fallback: string) {
  return list.includes(v) ? v : fallback;
}

export function parseBlocks(input: unknown): Block[] {
  if (!Array.isArray(input)) return [];
  const out: Block[] = [];
  for (const raw of input.slice(0, 24)) {
    if (!raw || typeof raw !== "object") continue;
    const b = raw as Record<string, unknown>;
    const type = b.type;
    if (type !== "lift" && type !== "str" && type !== "gym" && type !== "acc" && type !== "metcon" && type !== "cardio" && type !== "other") {
      continue;
    }
    if (type === "metcon") {
      const m = (b.m && typeof b.m === "object" ? b.m : {}) as Record<string, unknown>;
      out.push({
        type,
        m: {
          fmt: oneOf(clip(m.fmt, 24), METCON_FMTS, "AMRAP"),
          cap: clip(m.cap, 40),
          desc: clip(m.desc, 4000),
          score: clip(m.score, 80),
          rx: m.rx === "Scaled" ? "Scaled" : "RX",
        },
      });
      continue;
    }
    if (type === "cardio") {
      const c = (b.c && typeof b.c === "object" ? b.c : {}) as Record<string, unknown>;
      out.push({
        type,
        c: {
          mod: oneOf(clip(c.mod, 24), CARDIO_MODS, "Other"),
          dist: clip(c.dist, 40),
          time: clip(c.time, 40),
          notes: clip(c.notes, 500),
        },
      });
      continue;
    }
    if (type === "other") {
      out.push({ type, txt: clip(b.txt, 4000) });
      continue;
    }
    const exIn = Array.isArray(b.ex) ? b.ex : [];
    const ex: Exercise[] = [];
    for (const er of exIn.slice(0, 30)) {
      if (!er || typeof er !== "object") continue;
      const e = er as Record<string, unknown>;
      const u = e.u === "sec" || e.u === "min" || e.u === "reps" ? e.u : undefined;
      const sets: SetLine[] = [];
      const src = Array.isArray(e.sets) ? e.sets : [];
      for (const sr of src.slice(0, 40)) {
        if (!sr || typeof sr !== "object") continue;
        const s = sr as Record<string, unknown>;
        const line: SetLine = { w: clip(s.w, 16), r: clip(s.r, 16) };
        const p = clip(s.p, 12);
        if (p) line.p = p;
        if (s.d === 1 || s.d === true) line.d = 1;
        sets.push(line);
      }
      if (!sets.length) sets.push({ w: "", r: "" });
      const item: Exercise = { name: clip(e.name, 80), sets };
      if (u && (type === "gym" || type === "acc")) item.u = u;
      ex.push(item);
    }
    if (!ex.length) ex.push({ name: "", sets: [{ w: "", r: "" }] });
    out.push({ type, ex });
  }
  return out;
}

export function cleanBlocks(blocks: Block[]): Block[] {
  return blocks.map((b) => {
    if (!b.ex) return b;
    const ex = b.ex
      .map((e) => ({
        ...e,
        name: e.name.trim(),
        sets: e.sets.filter((s) => s.w || s.r || s.p || s.d),
      }))
      .filter((e) => e.name || e.sets.length);
    return { ...b, ex };
  });
}

export function sessionFromDraft(d: Draft): Session {
  return {
    id: d.id,
    date: d.date,
    title: d.title.trim(),
    notes: d.notes.trim(),
    blocks: cleanBlocks(d.blocks),
    rev: revNow(),
  };
}

export function planFromDraft(d: Draft): Plan {
  return {
    id: d.id,
    title: d.title.trim(),
    notes: d.notes.trim(),
    group: (d.group || "").trim(),
    blocks: cleanBlocks(d.blocks),
    rev: revNow(),
  };
}

export function hasSessionContent(s: Session) {
  if (s.title || s.notes) return true;
  return s.blocks.some((b) => {
    if (b.txt && b.txt.trim()) return true;
    if (b.m && (b.m.desc.trim() || b.m.score.trim() || b.m.cap.trim())) return true;
    if (b.c && (b.c.dist.trim() || b.c.time.trim() || b.c.notes.trim())) return true;
    return (b.ex || []).some((e) => e.name.trim() || e.sets.some((x) => x.w || x.r || x.p));
  });
}

export function hasPlanContent(p: Plan) {
  return hasSessionContent({ ...p, date: "2000-01-01" });
}

export function fmtSets(sets: SetLine[], unit?: string, gym?: boolean) {
  return sets
    .map((x) => {
      const load = gym ? "" : `${x.w ? x.w : "bw"}×`;
      const unitSuf = unit === "sec" ? "s" : unit === "min" ? "min" : "";
      const pct = x.p ? ` @${String(x.p).replace("%", "")}%` : "";
      const done = x.d ? " done" : "";
      return `${load}${x.r || "?"}${unitSuf}${pct}${done}`;
    })
    .join(", ");
}

export function blockNames(blocks: Block[]) {
  return [...new Set(blocks.map((b) => BLOCKS[b.type]?.n || b.type))].join(" + ");
}

export type Point = { d: string; w: number; r: number; rm: number; vol: number; tr: number; u: string };

export function series(sessions: Session[], name: string): Point[] {
  const n = name.trim().toLowerCase();
  const out: Point[] = [];
  [...sessions]
    .sort((a, b) => a.date.localeCompare(b.date))
    .forEach((s) => {
      let w = 0;
      let r = 0;
      let rm = 0;
      let vol = 0;
      let tr = 0;
      let u = "reps";
      s.blocks.forEach((b) =>
        (b.ex || []).forEach((e) => {
          if (e.name.trim().toLowerCase() !== n) return;
          u = e.u || "reps";
          e.sets.forEach((x) => {
            const W = parseFloat(x.w) || 0;
            const R = parseInt(x.r, 10) || 0;
            w = Math.max(w, W);
            r = Math.max(r, R);
            tr += R;
            vol += W * R;
            if (W > 0 && R > 0 && R <= 10) rm = Math.max(rm, W * (1 + R / 30));
          });
        }),
      );
      if (w || r) out.push({ d: s.date, w, r, rm, vol, tr, u });
    });
  return out;
}

export function estOf(sessions: Session[], name: string) {
  const pts = series(sessions, name);
  if (!pts.length) return 0;
  return Math.round(Math.max(0, ...pts.map((x) => x.rm)));
}

export function rmOf(sessions: Session[], orms: Orm[], name: string) {
  const n = name.trim().toLowerCase();
  const saved = orms.find((x) => x.n.toLowerCase() === n);
  return saved ? saved.v : estOf(sessions, name);
}

export function autoPct(sessions: Session[], orms: Orm[], name: string, w: string) {
  const m = rmOf(sessions, orms, name);
  const W = parseFloat(w);
  return m && W > 0 ? `${Math.round((W / m) * 100)}%` : "%";
}

export function lastOf(sessions: Session[], name: string, skipId?: string) {
  const n = name.trim().toLowerCase();
  if (!n) return "";
  const list = [...sessions].sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id));
  for (const s of list) {
    if (skipId && s.id === skipId) continue;
    for (const b of s.blocks) {
      for (const e of b.ex || []) {
        if (e.name.trim().toLowerCase() === n && e.sets.length) return fmtSets(e.sets, e.u, b.type === "gym");
      }
    }
  }
  return "";
}

export function hintOf(sessions: Session[], orms: Orm[], unit: Unit, name: string, skipId?: string) {
  const l = lastOf(sessions, name, skipId);
  const m = rmOf(sessions, orms, name);
  return [l ? `Last: ${l}` : "", m ? `1RM ${m} ${unit}` : ""].filter(Boolean).join(" · ");
}

export function allEx(sessions: Session[]) {
  const names = new Set<string>(DEX);
  sessions.forEach((s) =>
    s.blocks.forEach((b) => (b.ex || []).forEach((e) => {
      const n = e.name.trim();
      if (n) names.add(n);
    })),
  );
  return [...names].sort((a, b) => a.localeCompare(b));
}

export function isDate(v: string) {
  return /^\d{4}-\d{2}-\d{2}$/.test(v);
}
