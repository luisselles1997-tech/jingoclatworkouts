import {
  deletePlan,
  deleteSession,
  saveDraft,
  saveFood,
  saveFoodDay,
  saveOrm,
  savePlan,
  saveProfile,
  saveSession,
  loadLog,
} from "@/lib/log.functions";
import type { Draft, Food, FoodItem, Orm, Plan, Session, Snapshot, Unit } from "@/lib/model";

export type CacheBody = {
  name: string;
  unit: Unit;
  sessions: Session[];
  plans: Plan[];
  orms: Orm[];
  foods: Food[];
  food: Record<string, FoodItem[]>;
  draft: Draft | null;
};

export type Op =
  | { kind: "session"; session: Session }
  | { kind: "deleteSession"; sessionId: string }
  | { kind: "plan"; plan: Plan }
  | { kind: "deletePlan"; planId: string }
  | { kind: "orm"; name: string; value: number | null }
  | { kind: "foodDay"; day: string; items: FoodItem[] }
  | { kind: "food"; name: string; food: Food | null }
  | { kind: "draft"; draft: Draft | null }
  | { kind: "profile"; name: string; unit: Unit };

type Cache = CacheBody & { ops: Op[] };

function key(userId: string) {
  return `cflog.v1.${userId}`;
}

export function readCache(userId: string): Cache | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const raw = localStorage.getItem(key(userId));
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Cache;
    if (!parsed || !Array.isArray(parsed.ops)) return null;
    return parsed;
  } catch {
    return null;
  }
}

function writeCache(userId: string, cache: Cache) {
  try {
    localStorage.setItem(key(userId), JSON.stringify(cache));
  } catch {
    /* private mode or full storage — server is still the source of truth */
  }
}

function isPoison(e: unknown) {
  const m = e instanceof Error ? e.message : "";
  return /could not be read|valid date|too big|Missing workout|Missing plan|Missing lift|Missing food|Missing day|Missing profile|Name the|Enter a weight|Need grams/.test(m);
}

export function isAuthError(e: unknown) {
  const m = e instanceof Error ? e.message : String(e ?? "");
  return m === "Unauthorized" || m.includes("Unauthorized");
}
  const m = e instanceof Error ? e.message : String(e ?? "");
  return m === "Unauthorized" || m.includes("Unauthorized");
}

export function errorText(e: unknown) {
  if (e instanceof Error && e.message) return e.message;
  return "Couldn't reach the save. It's still on this phone.";
}

async function run(op: Op) {
  switch (op.kind) {
    case "session":
      await saveSession({ data: op.session });
      return;
    case "deleteSession":
      await deleteSession({ data: op.sessionId });
      return;
    case "plan":
      await savePlan({ data: op.plan });
      return;
    case "deletePlan":
      await deletePlan({ data: op.planId });
      return;
    case "orm":
      await saveOrm({ data: { name: op.name, value: op.value } });
      return;
    case "foodDay":
      await saveFoodDay({ data: { day: op.day, items: op.items } });
      return;
    case "food":
      await saveFood({
        data: op.food
          ? { name: op.food.n, k: op.food.k, g: op.food.g }
          : { name: op.name, remove: true },
      });
      return;
    case "draft":
      await saveDraft({ data: op.draft });
      return;
    case "profile":
      await saveProfile({ data: { name: op.name, unit: op.unit } });
      return;
  }
}

let chain: Promise<unknown> = Promise.resolve();

function lock<T>(fn: () => Promise<T>): Promise<T> {
  const run = chain.then(fn, fn);
  chain = run.then(
    () => undefined,
    () => undefined,
  );
  return run;
}

async function flushUnlocked(userId: string): Promise<"saved" | "local"> {
  const cache = readCache(userId);
  if (!cache || cache.ops.length === 0) return "saved";
  const remain: Op[] = [];
  let failed = false;
  for (const op of cache.ops) {
    if (failed) {
      remain.push(op);
      continue;
    }
    try {
      await run(op);
    } catch (e) {
      if (isAuthError(e)) throw e;
      if (isPoison(e)) continue;
      failed = true;
      remain.push(op);
    }
  }
  writeCache(userId, { ...cache, ops: remain });
  return failed ? "local" : "saved";
}

export function enqueue(userId: string, op: Op, body: CacheBody) {
  return lock(async () => {
    const prev = readCache(userId);
    writeCache(userId, { ...body, ops: [...(prev?.ops ?? []), op] });
    return flushUnlocked(userId);
  });
}

export function pullServer(userId: string, bodyIfPending: CacheBody | null) {
  return lock(async () => {
    const status = await flushUnlocked(userId);
    const cache = readCache(userId);
    if (cache && cache.ops.length) {
      return { status: "local" as const, snap: null as Snapshot | null };
    }
    const snap = await loadLog();
    const body: CacheBody = {
      name: snap.name,
      unit: snap.unit,
      sessions: snap.sessions,
      plans: snap.plans,
      orms: snap.orms,
      foods: snap.foods,
      food: snap.food,
      draft: snap.draft,
    };
    writeCache(userId, { ...body, ops: [] });
    void bodyIfPending;
    return { status, snap };
  });
}
