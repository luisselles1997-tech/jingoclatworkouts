import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import {
  isDate,
  parseBlocks,
  type Block,
  type BoxInfo,
  type Draft,
  type Food,
  type FoodItem,
  type Orm,
  type Plan,
  type Roster,
  type Session,
  type Snapshot,
  type Unit,
} from "@/lib/model";

function clip(v: unknown, max: number) {
  return typeof v === "string" ? v.slice(0, max) : "";
}

function asObj(v: unknown): Record<string, unknown> | null {
  return v && typeof v === "object" ? (v as Record<string, unknown>) : null;
}

function json<T>(v: unknown, fallback: T): T {
  if (typeof v === "string") {
    try {
      return JSON.parse(v) as T;
    } catch {
      return fallback;
    }
  }
  return (v as T) ?? fallback;
}

function parseSession(input: unknown): Session {
  const o = asObj(input);
  if (!o) throw new Error("That workout could not be read.");
  const id = clip(o.id, 80);
  if (!/^[A-Za-z0-9_-]{8,80}$/.test(id)) throw new Error("That workout could not be read.");
  const date = clip(o.date, 10);
  if (!isDate(date)) throw new Error("Pick a valid date.");
  const blocks = parseBlocks(o.blocks);
  if (JSON.stringify(blocks).length > 180000) throw new Error("That workout is too big to save.");
  return {
    id,
    date,
    title: clip(o.title, 120),
    notes: clip(o.notes, 4000),
    blocks,
    rev: clip(o.rev, 40) || new Date().toISOString(),
  };
}

function parsePlan(input: unknown): Plan {
  const o = asObj(input);
  if (!o) throw new Error("That plan could not be read.");
  const id = clip(o.id, 80);
  if (!/^[A-Za-z0-9_-]{8,80}$/.test(id)) throw new Error("That plan could not be read.");
  const blocks = parseBlocks(o.blocks);
  return {
    id,
    title: clip(o.title, 120),
    notes: clip(o.notes, 4000),
    group: clip(o.group, 60),
    blocks,
    rev: clip(o.rev, 40) || new Date().toISOString(),
  };
}

function parseDraft(input: unknown): Draft | null {
  if (input == null) return null;
  const o = asObj(input);
  if (!o) return null;
  const id = clip(o.id, 80);
  if (!/^[A-Za-z0-9_-]{8,80}$/.test(id)) return null;
  const date = clip(o.date, 10);
  return {
    id,
    date: isDate(date) ? date : "1970-01-01",
    title: clip(o.title, 120),
    notes: clip(o.notes, 4000),
    blocks: parseBlocks(o.blocks),
    plan: Boolean(o.plan),
    group: clip(o.group, 60),
  };
}

function outSession(row: Record<string, unknown>): Session {
  return {
    id: String(row.id),
    date: String(row.date).slice(0, 10),
    title: String(row.title ?? ""),
    notes: String(row.notes ?? ""),
    blocks: parseBlocks(json<Block[]>(row.blocks, [])),
    rev: String(row.rev ?? ""),
  };
}

function outPlan(row: Record<string, unknown>): Plan {
  return {
    id: String(row.id),
    title: String(row.title ?? ""),
    notes: String(row.notes ?? ""),
    group: String(row.group_name ?? ""),
    blocks: parseBlocks(json<Block[]>(row.blocks, [])),
    rev: String(row.rev ?? ""),
  };
}

function keyOf(name: string) {
  return name.trim().toLowerCase();
}

function code() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = new Uint8Array(6);
  crypto.getRandomValues(bytes);
  return [...bytes].map((n) => alphabet[n % alphabet.length]).join("");
}

export const loadLog = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Snapshot> => {
    const sql = await getSql();
    const uid = context.userId;
    await sql`insert into profiles (user_id) values (${uid}) on conflict (user_id) do nothing`;
    const [profile] = await sql<{ display_name: string; unit: string }>`
      select display_name, unit from profiles where user_id = ${uid}`;
    const sessionRows = await sql<Record<string, unknown>>`
      select id, date, title, notes, blocks, rev from sessions
      where user_id = ${uid} order by date desc, id desc limit 4000`;
    const planRows = await sql<Record<string, unknown>>`
      select id, title, notes, group_name, blocks, rev from plans
      where user_id = ${uid} order by title`;
    const ormRows = await sql<{ name: string; value: number }>`
      select name, value from one_rms where user_id = ${uid} order by name`;
    const foodRows = await sql<{ name: string; kcal_per_g: number; grams: number }>`
      select name, kcal_per_g, grams from saved_foods where user_id = ${uid} order by name`;
    const dayRows = await sql<{ day: string; items: unknown }>`
      select day, items from food_logs where user_id = ${uid} order by day desc limit 1200`;
    const [draftRow] = await sql<{ payload: unknown }>`
      select payload from drafts where user_id = ${uid}`;
    const [mem] = await sql<{ id: string; name: string; role: string; coach_name: string }>`
      select b.id, b.name, m.role,
             coalesce(nullif(pc.display_name, ''), 'Coach') as coach_name
      from memberships m
      join boxes b on b.id = m.box_id
      left join profiles pc on pc.user_id = b.coach_id
      where m.user_id = ${uid}`;
    const food: Record<string, FoodItem[]> = {};
    for (const row of dayRows) {
      const items = json<unknown>(row.items, []);
      food[row.day] = Array.isArray(items)
        ? items.slice(0, 80).flatMap((it) => {
            const o = asObj(it);
            if (!o) return [];
            const cal = Number(o.cal);
            if (!Number.isFinite(cal)) return [];
            return [{ n: clip(o.n, 80) || "Food", cal: Math.round(cal), g: Number(o.g) || 0 }];
          })
        : [];
    }
    const unit: Unit = profile?.unit === "kg" ? "kg" : "lb";
    const box: BoxInfo | null = mem
      ? {
          id: mem.id,
          name: mem.name,
          role: mem.role === "coach" ? "coach" : "athlete",
          coachName: mem.coach_name,
        }
      : null;
    return {
      name: profile?.display_name ?? "",
      unit,
      sessions: sessionRows.map(outSession),
      plans: planRows.map(outPlan),
      orms: ormRows.map((r) => ({ n: r.name, v: Number(r.value) || 0 })),
      foods: foodRows.map((r) => ({ n: r.name, k: Number(r.kcal_per_g) || 0, g: Number(r.grams) || 100 })),
      food,
      draft: parseDraft(json(draftRow?.payload ?? null, null)),
      box,
    };
  });

export const saveSession = createServerFn({ method: "POST" })
  .validator((input: unknown) => parseSession(input))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const uid = context.userId;
    await sql`
      insert into sessions (id, user_id, date, title, notes, blocks, rev)
      values (${data.id}, ${uid}, ${data.date}, ${data.title}, ${data.notes}, ${JSON.stringify(data.blocks)}::jsonb, ${data.rev})
      on conflict (id) do update set
        date = excluded.date,
        title = excluded.title,
        notes = excluded.notes,
        blocks = excluded.blocks,
        rev = excluded.rev,
        updated_at = now()
      where sessions.user_id = ${uid} and sessions.rev <= excluded.rev`;
    return { ok: true as const };
  });

export const deleteSession = createServerFn({ method: "POST" })
  .validator((id: unknown) => {
    const v = clip(id, 80);
    if (!/^[A-Za-z0-9_-]{8,80}$/.test(v)) throw new Error("Missing workout.");
    return v;
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data: id }) => {
    const sql = await getSql();
    await sql`delete from sessions where id = ${id} and user_id = ${context.userId}`;
    return { ok: true as const };
  });

export const savePlan = createServerFn({ method: "POST" })
  .validator((input: unknown) => parsePlan(input))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const uid = context.userId;
    await sql`
      insert into plans (id, user_id, title, notes, group_name, blocks, rev)
      values (${data.id}, ${uid}, ${data.title}, ${data.notes}, ${data.group}, ${JSON.stringify(data.blocks)}::jsonb, ${data.rev})
      on conflict (id) do update set
        title = excluded.title,
        notes = excluded.notes,
        group_name = excluded.group_name,
        blocks = excluded.blocks,
        rev = excluded.rev,
        updated_at = now()
      where plans.user_id = ${uid} and plans.rev <= excluded.rev`;
    return { ok: true as const };
  });

export const deletePlan = createServerFn({ method: "POST" })
  .validator((id: unknown) => {
    const v = clip(id, 80);
    if (!/^[A-Za-z0-9_-]{8,80}$/.test(v)) throw new Error("Missing plan.");
    return v;
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data: id }) => {
    const sql = await getSql();
    await sql`delete from plans where id = ${id} and user_id = ${context.userId}`;
    return { ok: true as const };
  });

export const saveDraft = createServerFn({ method: "POST" })
  .validator((input: unknown) => parseDraft(input))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const uid = context.userId;
    if (!data) {
      await sql`delete from drafts where user_id = ${uid}`;
      return { ok: true as const };
    }
    await sql`
      insert into drafts (user_id, payload) values (${uid}, ${JSON.stringify(data)}::jsonb)
      on conflict (user_id) do update set payload = excluded.payload, updated_at = now()`;
    return { ok: true as const };
  });

export const saveProfile = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const o = asObj(input);
    if (!o) throw new Error("Missing profile.");
    const unit: Unit = o.unit === "kg" ? "kg" : "lb";
    return { name: clip(o.name, 80).trim(), unit };
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`
      insert into profiles (user_id, display_name, unit)
      values (${context.userId}, ${data.name}, ${data.unit})
      on conflict (user_id) do update set
        display_name = excluded.display_name,
        unit = excluded.unit,
        updated_at = now()`;
    return { ok: true as const };
  });

export const saveOrm = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const o = asObj(input);
    if (!o) throw new Error("Missing lift.");
    const name = clip(o.name, 80).trim();
    if (!name) throw new Error("Name the lift.");
    const value = o.value == null || o.value === "" ? null : Number(o.value);
    if (value != null && !(value > 0 && value < 2000)) throw new Error("Enter a weight.");
    return { name, value };
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const key = keyOf(data.name);
    if (data.value == null) {
      await sql`delete from one_rms where user_id = ${context.userId} and name_key = ${key}`;
    } else {
      await sql`
        insert into one_rms (user_id, name_key, name, value)
        values (${context.userId}, ${key}, ${data.name}, ${data.value})
        on conflict (user_id, name_key) do update set name = excluded.name, value = excluded.value`;
    }
    return { ok: true as const };
  });

function parseItems(input: unknown): FoodItem[] {
  if (!Array.isArray(input)) return [];
  return input.slice(0, 80).flatMap((it) => {
    const o = asObj(it);
    if (!o) return [];
    const cal = Number(o.cal);
    if (!Number.isFinite(cal) || cal < 0 || cal > 20000) return [];
    const g = Number(o.g);
    return [{ n: clip(o.n, 80).trim() || "Food", cal: Math.round(cal), g: Number.isFinite(g) && g > 0 ? Math.round(g * 10) / 10 : 0 }];
  });
}

export const saveFoodDay = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const o = asObj(input);
    if (!o) throw new Error("Missing day.");
    const day = clip(o.day, 10);
    if (!isDate(day)) throw new Error("Pick a valid date.");
    return { day, items: parseItems(o.items) };
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    if (!data.items.length) {
      await sql`delete from food_logs where user_id = ${context.userId} and day = ${data.day}`;
    } else {
      await sql`
        insert into food_logs (user_id, day, items)
        values (${context.userId}, ${data.day}, ${JSON.stringify(data.items)}::jsonb)
        on conflict (user_id, day) do update set items = excluded.items`;
    }
    return { ok: true as const };
  });

export const saveFood = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const o = asObj(input);
    if (!o) throw new Error("Missing food.");
    const name = clip(o.name, 80).trim();
    if (!name) throw new Error("Name the food.");
    if (o.remove) return { name, remove: true as const, k: 0, g: 0 };
    const k = Number(o.k);
    const g = Number(o.g);
    if (!(k > 0) || !(g > 0)) throw new Error("Need grams and calories.");
    return { name, remove: false as const, k, g };
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const key = keyOf(data.name);
    if (data.remove) {
      await sql`delete from saved_foods where user_id = ${context.userId} and name_key = ${key}`;
    } else {
      await sql`
        insert into saved_foods (user_id, name_key, name, kcal_per_g, grams)
        values (${context.userId}, ${key}, ${data.name}, ${data.k}, ${data.g})
        on conflict (user_id, name_key) do update set
          name = excluded.name, kcal_per_g = excluded.kcal_per_g, grams = excluded.grams`;
    }
    return { ok: true as const };
  });

export const createBox = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const o = asObj(input);
    const name = clip(o?.name, 60).trim();
    if (name.length < 2) throw new Error("Name your box.");
    return { name, replace: Boolean(o?.replace) };
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const uid = context.userId;
    const [mem] = await sql<{ role: string }>`select role from memberships where user_id = ${uid}`;
    if (mem?.role === "coach") throw new Error("You already have a box. Close it before starting another.");
    if (mem && !data.replace) throw new Error("Leave your current box first.");
    if (mem && data.replace) await sql`delete from memberships where user_id = ${uid}`;
    let id = code();
    for (let i = 0; i < 5; i++) {
      const [hit] = await sql<{ id: string }>`select id from boxes where id = ${id}`;
      if (!hit) break;
      id = code();
    }
    await sql`insert into boxes (id, name, coach_id) values (${id}, ${data.name}, ${uid})`;
    await sql`insert into memberships (user_id, box_id, role) values (${uid}, ${id}, 'coach')`;
    return { id, name: data.name };
  });

export const joinBox = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const codeIn = clip(typeof input === "string" ? input : asObj(input)?.code, 8).trim().toUpperCase();
    if (!/^[A-Z0-9]{4,8}$/.test(codeIn)) throw new Error("Enter the box code.");
    return codeIn;
  })
  .middleware([authMiddleware])
  .handler(async ({ context, data: codeIn }) => {
    const sql = await getSql();
    const uid = context.userId;
    const [box] = await sql<{ id: string; name: string; coach_id: string }>`
      select id, name, coach_id from boxes where id = ${codeIn}`;
    if (!box) throw new Error("No box with that code.");
    if (box.coach_id === uid) throw new Error("You already run this box.");
    const [mem] = await sql<{ role: string }>`select role from memberships where user_id = ${uid}`;
    if (mem?.role === "coach") throw new Error("Close your box before joining one.");
    if (mem) throw new Error("Leave your current box first.");
    await sql`insert into memberships (user_id, box_id, role) values (${uid}, ${box.id}, 'athlete')`;
    return { id: box.id, name: box.name };
  });

export const leaveBox = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const uid = context.userId;
    const [mem] = await sql<{ role: string; box_id: string }>`
      select role, box_id from memberships where user_id = ${uid}`;
    if (!mem) return { ok: true as const };
    if (mem.role === "coach") {
      await sql`delete from boxes where id = ${mem.box_id} and coach_id = ${uid}`;
    } else {
      await sql`delete from memberships where user_id = ${uid}`;
    }
    return { ok: true as const };
  });

export const loadRoster = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Roster | null> => {
    const sql = await getSql();
    const uid = context.userId;
    const [box] = await sql<{ id: string; name: string }>`
      select id, name from boxes where coach_id = ${uid}`;
    if (!box) return null;
    const people = await sql<{ user_id: string; name: string }>`
      select m.user_id, coalesce(nullif(p.display_name, ''), 'Athlete') as name
      from memberships m
      left join profiles p on p.user_id = m.user_id
      where m.box_id = ${box.id} and m.role = 'athlete'
      order by name`;
    const rows = await sql<Record<string, unknown>>`
      select s.user_id, s.id, s.date, s.title, s.notes, s.blocks, s.rev
      from sessions s
      join memberships m on m.user_id = s.user_id and m.box_id = ${box.id} and m.role = 'athlete'
      order by s.date desc, s.id desc
      limit 800`;
    const byId = new Map<string, Session[]>();
    for (const row of rows) {
      const id = String(row.user_id);
      const list = byId.get(id) ?? [];
      if (list.length < 40) list.push(outSession(row));
      byId.set(id, list);
    }
    return {
      boxName: box.name,
      code: box.id,
      athletes: people.map((p) => ({
        id: p.user_id,
        name: p.name,
        sessions: byId.get(p.user_id) ?? [],
      })),
    };
  });

export type { Food, Orm, Session };
