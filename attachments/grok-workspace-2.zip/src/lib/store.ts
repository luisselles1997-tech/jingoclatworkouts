import { create } from "zustand";
import { loadLog } from "@/lib/log.functions";
import { enqueue, errorText, isAuthError, pullServer, readCache, type CacheBody } from "@/lib/outbox";
import { createBox, joinBox, leaveBox, loadRoster } from "@/lib/log.functions";
import {
  addD,
  hasPlanContent,
  hasSessionContent,
  mk,
  monOf,
  planFromDraft,
  sessionFromDraft,
  today,
  uid,
  type Block,
  type BlockType,
  type BoxInfo,
  type Draft,
  type Food,
  type FoodItem,
  type Orm,
  type Plan,
  type Roster,
  type Session,
  type Unit,
} from "@/lib/model";

export type Tab = "today" | "week" | "month" | "plan" | "timer" | "log" | "food" | "box";
export type LogSub = "hist" | "prog" | "orm";
export type Sync = "saved" | "saving" | "local";

type State = {
  ready: boolean;
  failed: string;
  userId: string;
  sync: Sync;
  name: string;
  unit: Unit;
  theme: "dark" | "light";
  tab: Tab;
  sub: LogSub;
  td: string;
  wm: string;
  mc: string;
  fd: string;
  sessions: Session[];
  plans: Plan[];
  orms: Orm[];
  foods: Food[];
  food: Record<string, FoodItem[]>;
  draft: Draft | null;
  box: BoxInfo | null;
  roster: Roster | null;
  rosterBusy: boolean;
  hq: string;
  pick: string;
  toast: string;
  boot: (userId: string, suggestedName: string) => Promise<void>;
  setTab: (tab: Tab) => void;
  setSub: (sub: LogSub) => void;
  setTheme: (theme: "dark" | "light") => void;
  toggleUnit: () => void;
  setName: (name: string) => void;
  shiftDay: (n: number) => void;
  shiftWeek: (n: number) => void;
  shiftMonth: (n: number) => void;
  pickDay: (d: string) => void;
  setFd: (d: string) => void;
  shiftFd: (n: number) => void;
  setHq: (q: string) => void;
  setPick: (name: string) => void;
  showToast: (m: string) => void;
  startDraft: (types: BlockType[], plan: boolean) => void;
  patchDraft: (partial: Partial<Draft>) => void;
  setBlocks: (blocks: Block[]) => void;
  discard: () => void;
  saveWorkout: () => void;
  savePlanDraft: () => void;
  editSession: (id: string) => void;
  deleteSession: (id: string) => void;
  editPlan: (id: string) => void;
  deletePlan: (id: string) => void;
  startPlan: (id: string) => void;
  setOrm: (name: string, value: number | null) => void;
  setFoodDay: (day: string, items: FoodItem[]) => void;
  upsertFood: (food: Food) => void;
  removeFood: (name: string) => void;
  createBox: (name: string, replace: boolean) => Promise<void>;
  joinBox: (code: string) => Promise<void>;
  leaveBox: () => Promise<void>;
  refreshRoster: () => Promise<void>;
  importBackup: (data: unknown) => Promise<void>;
};

let toastTimer = 0;
let draftTimer = 0;
let bootUid = "";
let bootPromise: Promise<void> | null = null;

function bodyOf(s: State): CacheBody {
  return {
    name: s.name,
    unit: s.unit,
    sessions: s.sessions,
    plans: s.plans,
    orms: s.orms,
    foods: s.foods,
    food: s.food,
    draft: s.draft,
  };
}

function upsertById<T extends { id: string }>(list: T[], item: T) {
  const i = list.findIndex((x) => x.id === item.id);
  if (i < 0) return [item, ...list];
  const next = list.slice();
  next[i] = item;
  return next;
}

export const useLog = create<State>((set, get) => {
  const toast = (m: string) => {
    window.clearTimeout(toastTimer);
    set({ toast: m });
    toastTimer = window.setTimeout(() => set({ toast: "" }), 2400);
  };

  const commit = async (op: Parameters<typeof enqueue>[1]) => {
    const s = get();
    set({ sync: "saving" });
    try {
      const status = await enqueue(s.userId, op, bodyOf(get()));
      if (get().userId === s.userId) set({ sync: status });
    } catch (e) {
      if (isAuthError(e)) {
        set({ failed: "Sign in again to keep saving." });
        return;
      }
      set({ sync: "local" });
    }
  };

  const scheduleDraft = () => {
    window.clearTimeout(draftTimer);
    draftTimer = window.setTimeout(() => {
      const s = get();
      if (!s.userId) return;
      void commit({ kind: "draft", draft: s.draft });
    }, 700);
  };

  return {
    ready: false,
    failed: "",
    userId: "",
    sync: "saved",
    name: "",
    unit: "lb",
    theme: "dark",
    tab: "today",
    sub: "hist",
    td: today(),
    wm: monOf(today()),
    mc: today().slice(0, 7),
    fd: today(),
    sessions: [],
    plans: [],
    orms: [],
    foods: [],
    food: {},
    draft: null,
    box: null,
    roster: null,
    rosterBusy: false,
    hq: "",
    pick: "",
    toast: "",
    showToast: toast,
    async boot(userId, suggestedName) {
      if (bootUid === userId && bootPromise && !get().failed) return bootPromise;
      bootUid = userId;
      const run = async () => {
      const theme = localStorage.getItem("cflog.theme") === "light" ? "light" : "dark";
      const cached = readCache(userId);
      set({
        userId,
        theme,
        ready: Boolean(cached),
        failed: "",
        name: cached?.name ?? "",
        unit: cached?.unit === "kg" ? "kg" : "lb",
        sessions: cached?.sessions ?? [],
        plans: cached?.plans ?? [],
        orms: cached?.orms ?? [],
        foods: cached?.foods ?? [],
        food: cached?.food ?? {},
        draft: cached?.draft ?? null,
        sync: cached?.ops.length ? "local" : "saving",
      });
      try {
        const { status, snap } = await pullServer(userId, null);
        if (get().userId !== userId) return;
        if (snap) {
          const name = snap.name || suggestedName || "";
          set({
            ready: true,
            failed: "",
            sync: status,
            name,
            unit: snap.unit,
            sessions: snap.sessions,
            plans: snap.plans,
            orms: snap.orms,
            foods: snap.foods,
            food: snap.food,
            draft: snap.draft,
            box: snap.box,
          });
          if (!snap.name && suggestedName) {
            set({ name: suggestedName });
            void commit({ kind: "profile", name: suggestedName, unit: snap.unit });
          }
        } else {
          set({ ready: true, sync: "local", failed: "" });
        }
      } catch (e) {
        if (get().userId !== userId) return;
        if (cached) set({ ready: true, sync: "local" });
        else set({ ready: true, failed: errorText(e) });
      }
      };
      bootPromise = run();
      return bootPromise;
    },
    setTab(tab) {
      set({ tab });
      if (tab === "box") void get().refreshRoster();
    },
    setSub(sub) {
      set({ sub });
    },
    setTheme(theme) {
      localStorage.setItem("cflog.theme", theme);
      set({ theme });
    },
    toggleUnit() {
      const unit: Unit = get().unit === "lb" ? "kg" : "lb";
      set({ unit });
      void commit({ kind: "profile", name: get().name, unit });
    },
    setName(name) {
      set({ name });
      void commit({ kind: "profile", name, unit: get().unit });
    },
    shiftDay(n) {
      set({ td: addD(get().td, n) });
    },
    shiftWeek(n) {
      set({ wm: addD(get().wm, n) });
    },
    shiftMonth(n) {
      const [y, m] = get().mc.split("-").map(Number);
      const x = new Date(y, m - 1 + n, 1);
      set({ mc: `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, "0")}` });
    },
    pickDay(d) {
      set({ td: d, tab: "today" });
    },
    setFd(d) {
      if (d) set({ fd: d });
    },
    shiftFd(n) {
      set({ fd: addD(get().fd, n) });
    },
    setHq(q) {
      set({ hq: q });
    },
    setPick(name) {
      set({ pick: name });
    },
    startDraft(types, plan) {
      const s = get();
      if (s.draft) {
        toast(s.draft.plan ? "Finish or discard the plan first." : "Finish or discard the open workout first.");
        return;
      }
      if (!types.length) return;
      const draft: Draft = {
        id: uid(),
        date: s.td,
        title: "",
        notes: "",
        blocks: types.map(mk),
        plan,
        group: "",
      };
      set({ draft, tab: plan ? "plan" : "today" });
      scheduleDraft();
    },
    patchDraft(partial) {
      const d = get().draft;
      if (!d) return;
      set({ draft: { ...d, ...partial } });
      scheduleDraft();
    },
    setBlocks(blocks) {
      const d = get().draft;
      if (!d) return;
      set({ draft: { ...d, blocks } });
      scheduleDraft();
    },
    discard() {
      window.clearTimeout(draftTimer);
      set({ draft: null });
      void commit({ kind: "draft", draft: null });
    },
    saveWorkout() {
      const d = get().draft;
      if (!d || d.plan) return;
      const session = sessionFromDraft(d);
      if (!hasSessionContent(session)) {
        toast("Add a lift, a score, or a note first.");
        return;
      }
      window.clearTimeout(draftTimer);
      set({ sessions: upsertById(get().sessions, session), draft: null, tab: "log", sub: "hist", sync: "saving" });
      void (async () => {
        await commit({ kind: "session", session });
        await commit({ kind: "draft", draft: null });
        toast("Saved to your account");
      })();
    },
    savePlanDraft() {
      const d = get().draft;
      if (!d?.plan) return;
      const plan = planFromDraft(d);
      if (!hasPlanContent(plan)) {
        toast("Add something to the plan first.");
        return;
      }
      window.clearTimeout(draftTimer);
      set({ plans: upsertById(get().plans, plan), draft: null, sync: "saving" });
      void (async () => {
        await commit({ kind: "plan", plan });
        await commit({ kind: "draft", draft: null });
        toast("Plan saved");
      })();
    },
    editSession(id) {
      const s = get().sessions.find((x) => x.id === id);
      if (!s) return;
      if (get().draft) {
        toast("Finish or discard the open workout first.");
        return;
      }
      set({
        draft: { id: s.id, date: s.date, title: s.title, notes: s.notes, blocks: structuredClone(s.blocks), plan: false },
        tab: "today",
        td: s.date,
      });
      scheduleDraft();
    },
    deleteSession(id) {
      set({ sessions: get().sessions.filter((x) => x.id !== id) });
      void commit({ kind: "deleteSession", sessionId: id });
      toast("Workout deleted");
    },
    editPlan(id) {
      const p = get().plans.find((x) => x.id === id);
      if (!p) return;
      if (get().draft) {
        toast("Finish or discard what's open first.");
        return;
      }
      set({
        draft: {
          id: p.id,
          date: get().td,
          title: p.title,
          notes: p.notes,
          group: p.group,
          blocks: structuredClone(p.blocks),
          plan: true,
        },
        tab: "plan",
      });
      scheduleDraft();
    },
    deletePlan(id) {
      set({ plans: get().plans.filter((x) => x.id !== id) });
      void commit({ kind: "deletePlan", planId: id });
    },
    startPlan(id) {
      const p = get().plans.find((x) => x.id === id);
      if (!p) return;
      if (get().draft) {
        toast("Finish or discard the open workout first.");
        return;
      }
      set({
        draft: {
          id: uid(),
          date: get().td,
          title: p.title,
          notes: p.notes,
          blocks: structuredClone(p.blocks),
          plan: false,
        },
        tab: "today",
      });
      scheduleDraft();
    },
    setOrm(name, value) {
      const n = name.trim();
      if (!n) return;
      const orms = get().orms.filter((x) => x.n.toLowerCase() !== n.toLowerCase());
      if (value && value > 0) orms.push({ n, v: value });
      orms.sort((a, b) => a.n.localeCompare(b.n));
      set({ orms });
      void commit({ kind: "orm", name: n, value: value && value > 0 ? value : null });
    },
    setFoodDay(day, items) {
      const food = { ...get().food };
      if (items.length) food[day] = items;
      else delete food[day];
      set({ food });
      void commit({ kind: "foodDay", day, items });
    },
    upsertFood(food) {
      const foods = get().foods.filter((x) => x.n.toLowerCase() !== food.n.toLowerCase());
      foods.push(food);
      foods.sort((a, b) => a.n.localeCompare(b.n));
      set({ foods });
      void commit({ kind: "food", name: food.n, food });
    },
    removeFood(name) {
      set({ foods: get().foods.filter((x) => x.n.toLowerCase() !== name.toLowerCase()) });
      void commit({ kind: "food", name, food: null });
    },
    async createBox(name, replace) {
      try {
        const box = await createBox({ data: { name, replace } });
        const snap = await loadLog();
        set({ box: snap.box ?? { id: box.id, name: box.name, role: "coach", coachName: get().name || "Coach" } });
        toast("Box is ready. Share the code.");
        await get().refreshRoster();
      } catch (e) {
        toast(errorText(e));
      }
    },
    async joinBox(code) {
      try {
        await joinBox({ data: code });
        const snap = await loadLog();
        set({ box: snap.box });
        toast(snap.box ? `Joined ${snap.box.name}` : "Joined");
      } catch (e) {
        toast(errorText(e));
      }
    },
    async leaveBox() {
      try {
        await leaveBox();
        set({ box: null, roster: null });
        toast("Your workouts are still on your account.");
      } catch (e) {
        toast(errorText(e));
      }
    },
    async refreshRoster() {
      if (get().box?.role !== "coach") {
        set({ roster: null });
        return;
      }
      set({ rosterBusy: true });
      try {
        const roster = await loadRoster();
        set({ roster, rosterBusy: false });
      } catch (e) {
        set({ rosterBusy: false });
        toast(errorText(e));
      }
    },
    async importBackup(data) {
      const o = data && typeof data === "object" ? (data as Record<string, unknown>) : null;
      if (!o) {
        toast("That file isn't a backup.");
        return;
      }
      const sessions = Array.isArray(o.sessions) ? o.sessions : [];
      const plans = Array.isArray(o.plans) ? o.plans : [];
      let n = 0;
      for (const raw of sessions) {
        try {
          const session = sessionFromDraft({
            ...(raw as Draft),
            id: typeof (raw as Session).id === "string" && (raw as Session).id.length >= 8 ? (raw as Session).id : uid(),
            plan: false,
          });
          if (!hasSessionContent(session)) continue;
          set({ sessions: upsertById(get().sessions, session) });
          await commit({ kind: "session", session });
          n += 1;
        } catch {
          /* skip a bad row, keep going */
        }
      }
      for (const raw of plans) {
        try {
          const plan = planFromDraft({
            id: uid(),
            date: today(),
            title: "",
            notes: "",
            blocks: [],
            ...(raw as Draft),
            plan: true,
          });
          if (!plan.id || plan.id.length < 8) plan.id = uid();
          if (!hasPlanContent(plan)) continue;
          set({ plans: upsertById(get().plans, plan) });
          await commit({ kind: "plan", plan });
          n += 1;
        } catch {
          /* skip */
        }
      }
      toast(n ? `Brought in ${n} item${n === 1 ? "" : "s"}` : "Nothing new in that file.");
    },
  };
});
