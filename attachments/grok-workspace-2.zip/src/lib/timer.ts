export type TimerMode = "time" | "amrap" | "int";

export type TimerCfg = {
  mode: TimerMode;
  rd: number;
  cap: number;
  am: number;
  an: number;
  ar: number;
  w: number;
  r: number;
  n: number;
  sn: number;
  sr: number;
};

type Seg = { l: string; s: number; k: "work" | "rest"; up?: boolean; a?: number };

const TD: TimerCfg = { mode: "time", rd: 10, cap: 0, am: 10, an: 1, ar: 60, w: 20, r: 10, n: 8, sn: 1, sr: 60 };

function audioCtor() {
  if (typeof window === "undefined") return null;
  const w = window as Window & { webkitAudioContext?: typeof AudioContext };
  return w.AudioContext || w.webkitAudioContext || null;
}

function loadCfg(): TimerCfg {
  try {
    const raw = localStorage.getItem("cflog.timer");
    if (!raw) return { ...TD };
    const p = JSON.parse(raw) as Partial<TimerCfg>;
    return { ...TD, ...p, mode: p.mode === "amrap" || p.mode === "int" ? p.mode : "time" };
  } catch {
    return { ...TD };
  }
}

const state = {
  st: "idle" as "idle" | "run" | "pause" | "done",
  cfg: typeof localStorage === "undefined" ? { ...TD } : loadCfg(),
  segs: [] as Seg[],
  idx: 0,
  t0: 0,
  pa: 0,
  beeped: {} as Record<number, number>,
  sc: {} as Record<number, number>,
  ac: null as AudioContext | null,
  wl: null as { release: () => Promise<void> } | null,
};

const listeners = new Set<() => void>();

function emit() {
  listeners.forEach((fn) => fn());
}

export function subscribeTimer(fn: () => void) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

function num(k: keyof TimerCfg) {
  const v = Number(state.cfg[k]);
  return v >= 0 && Number.isFinite(v) ? v : Number(TD[k]);
}

function segs(): Seg[] {
  const s: Seg[] = [];
  if (num("rd") > 0) s.push({ l: "Get ready", s: num("rd"), k: "rest" });
  if (state.cfg.mode === "time") s.push({ l: "For time", s: num("cap") * 60, k: "work", up: true });
  else if (state.cfg.mode === "amrap") {
    const n = Math.max(1, Math.round(num("an")));
    for (let a = 1; a <= n; a++) {
      s.push({ l: `AMRAP${n > 1 ? ` ${a} of ${n}` : ""}`, s: num("am") * 60, k: "work", a: a - 1 });
      if (a < n && num("ar") > 0) s.push({ l: "Rest", s: num("ar"), k: "rest" });
    }
  } else {
    const rounds = Math.max(1, Math.round(num("n")));
    const sn = Math.max(1, Math.round(num("sn")));
    for (let q = 1; q <= sn; q++) {
      for (let r = 1; r <= rounds; r++) {
        s.push({ l: `Work ${r}/${rounds}${sn > 1 ? ` · set ${q}` : ""}`, s: num("w"), k: "work" });
        if (r < rounds && num("r") > 0) s.push({ l: "Rest", s: num("r"), k: "rest" });
      }
      if (q < sn && num("sr") > 0) s.push({ l: "Rest between sets", s: num("sr"), k: "rest" });
    }
  }
  return s.filter((x) => x.s > 0 || x.up);
}

export function fmtClock(x: number) {
  const s = Math.max(0, Math.round(x));
  return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}

function beep(long?: boolean) {
  try {
    const AC = audioCtor();
    if (!AC) return;
    state.ac = state.ac || new AC();
    const c = state.ac;
    const o = c.createOscillator();
    const g = c.createGain();
    const d = long ? 0.6 : 0.15;
    o.frequency.value = long ? 880 : 660;
    o.connect(g);
    g.connect(c.destination);
    g.gain.setValueAtTime(0.25, c.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + d);
    o.start();
    o.stop(c.currentTime + d);
  } catch {
    /* autoplay blocked */
  }
}

async function wlOn() {
  try {
    const nav = navigator as Navigator & { wakeLock?: { request: (t: "screen") => Promise<{ release: () => Promise<void> }> } };
    if (nav.wakeLock && !state.wl) {
      state.wl = await nav.wakeLock.request("screen");
    }
  } catch {
    /* optional */
  }
}

function wlOff() {
  try {
    void state.wl?.release();
  } catch {
    /* ignore */
  }
  state.wl = null;
}

export function setTimerField(key: Exclude<keyof TimerCfg, "mode">, value: number) {
  state.cfg = { ...state.cfg, [key]: value };
  try {
    localStorage.setItem("cflog.timer", JSON.stringify(state.cfg));
  } catch {
    /* ignore */
  }
  emit();
}

export function setTimerMode(mode: TimerMode) {
  state.cfg = { ...state.cfg, mode };
  try {
    localStorage.setItem("cflog.timer", JSON.stringify(state.cfg));
  } catch {
    /* ignore */
  }
  emit();
}

export function applyTimerPreset(partial: Partial<TimerCfg>) {
  state.cfg = { ...state.cfg, ...partial };
  try {
    localStorage.setItem("cflog.timer", JSON.stringify(state.cfg));
  } catch {
    /* ignore */
  }
  emit();
}

export function timerTotal() {
  if (state.st !== "idle") return 0;
  return segs().reduce((a, x) => a + x.s, 0);
}

export function timerView() {
  const live = state.st === "run" || state.st === "pause";
  const sg = state.segs[state.idx];
  const el = state.st === "run" ? (Date.now() - state.t0) / 1000 : state.st === "pause" ? (state.pa - state.t0) / 1000 : 0;
  const sec = sg && live ? (sg.up ? Math.floor(el) : Math.ceil(sg.s - el)) : 0;
  const nx = state.segs[state.idx + 1];
  return {
    st: state.st,
    mode: state.cfg.mode,
    cfg: state.cfg,
    clock: state.st === "done" ? "DONE" : fmtClock(sec),
    label: live && sg ? sg.l : state.st === "done" ? "Finished" : "",
    next: live && nx ? `Next: ${nx.l}${nx.s > 0 ? ` ${fmtClock(nx.s)}` : ""}` : "",
    rest: Boolean(live && sg && sg.k === "rest"),
    live,
    round: state.cfg.mode === "amrap" && live && sg && sg.a !== undefined ? state.sc[sg.a] || 0 : null,
    summary:
      state.cfg.mode === "amrap" && Object.keys(state.sc).length
        ? Object.keys(state.sc)
            .sort()
            .map((a) => `AMRAP ${Number(a) + 1}: ${state.sc[Number(a)]} rounds`)
            .join(" · ")
        : "",
    total: timerTotal(),
  };
}

export function timerStart() {
  const sg = segs();
  if (!sg.length) return false;
  state.segs = sg;
  state.idx = 0;
  state.sc = {};
  state.beeped = {};
  state.t0 = Date.now();
  state.pa = 0;
  state.st = "run";
  try {
    const AC = audioCtor();
    if (AC) {
      state.ac = state.ac || new AC();
      void state.ac.resume();
    }
  } catch {
    /* ignore */
  }
  void wlOn();
  emit();
  return true;
}

export function timerPause() {
  const n = Date.now();
  if (state.st === "run") {
    state.st = "pause";
    state.pa = n;
  } else if (state.st === "pause") {
    state.t0 += n - state.pa;
    state.pa = 0;
    state.st = "run";
  }
  emit();
}

export function timerSkip() {
  if (state.st !== "run" && state.st !== "pause") return;
  const sg = state.segs[state.idx];
  if (!sg || sg.up || state.idx >= state.segs.length - 1) {
    timerDone();
    return;
  }
  state.idx += 1;
  state.beeped = {};
  state.t0 = Date.now();
  if (state.st === "pause") state.pa = Date.now();
  emit();
}

export function timerReset() {
  state.st = "idle";
  state.segs = [];
  state.idx = 0;
  state.sc = {};
  wlOff();
  emit();
}

function timerDone() {
  state.st = "done";
  wlOff();
  beep(true);
  setTimeout(() => beep(true), 500);
  setTimeout(() => beep(true), 1000);
  emit();
}

export function timerRound(delta: number) {
  const sg = state.segs[state.idx];
  if (!sg || sg.a === undefined) return;
  state.sc[sg.a] = Math.max(0, (state.sc[sg.a] || 0) + delta);
  emit();
}

function tick() {
  if (state.st !== "run") return;
  const now = Date.now();
  let sg = state.segs[state.idx];
  while (sg && !sg.up && now - state.t0 >= sg.s * 1000) {
    state.t0 += sg.s * 1000;
    state.idx += 1;
    state.beeped = {};
    sg = state.segs[state.idx];
    if (sg) beep(true);
  }
  if (!sg) {
    timerDone();
    return;
  }
  const el = (now - state.t0) / 1000;
  if (sg.up) {
    if (sg.s > 0 && el >= sg.s) {
      timerDone();
      return;
    }
  } else {
    const c = Math.ceil(sg.s - el);
    if (c >= 1 && c <= 3 && !state.beeped[c]) {
      state.beeped[c] = 1;
      beep(false);
    }
  }
  emit();
}

if (typeof window !== "undefined") {
  window.setInterval(tick, 250);
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && state.st === "run") {
      state.wl = null;
      void wlOn();
    }
  });
}

export function primeMetcon(fmt: string, cap: string) {
  if (state.st === "run" || state.st === "pause") return false;
  const c = parseFloat(cap) || 0;
  if (fmt === "AMRAP") applyTimerPreset({ mode: "amrap", am: c || 10, an: 1 });
  else if (fmt === "EMOM") applyTimerPreset({ mode: "int", w: 60, r: 0, n: c || 10, sn: 1 });
  else if (fmt === "Tabata") applyTimerPreset({ mode: "int", w: 20, r: 10, n: 8, sn: 1 });
  else applyTimerPreset({ mode: "time", cap: c });
  return true;
}
