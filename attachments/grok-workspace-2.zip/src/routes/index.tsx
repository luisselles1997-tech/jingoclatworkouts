import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { SignInGate } from "@/lib/auth/gates";
import { LogApp } from "@/components/log-app";
import { SignInPanel } from "@/components/sign-in-panel";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) return <main className="min-h-screen bg-bg" />;
  return (
    <SignInGate fallback={<SignInPanel />}>
      <LogApp />
    </SignInGate>
  );
}
