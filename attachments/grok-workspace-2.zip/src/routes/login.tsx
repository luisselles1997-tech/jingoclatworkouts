import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { SignInPanel } from "@/components/sign-in-panel";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <main className="min-h-screen bg-bg" />;
  if (user) return <Navigate to="/" />;
  return <SignInPanel />;
}
